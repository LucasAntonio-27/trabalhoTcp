/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Link referencia: https://www.devmedia.com.br/java-socket-transferencia-de-arquivos-pela-rede/32107
 * Aluno: Lucas Antonio da Silva Lima
 */
package tcpCliente;
import java.io.*;
import java.net.*;
import tcpArquivos.ManipulacaoArquivos;

public class ClienteTCP {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String enderecoServidor = "127.0.0.1";
		//String enderecoServidor = "work";
		int portaServidor = 4444;
		
		try {
			//Criação de socket
			Socket tomadaCliente = new Socket(enderecoServidor,
					portaServidor);
			
			// cria dois buffers de array de bytes, um para enviar, outro para receber da conexão do cliente
			//Output de Objetos
			ObjectOutputStream bufferSaida = new ObjectOutputStream(tomadaCliente.getOutputStream());
			//Input de dados
			DataInputStream bufferEntrada = new DataInputStream(tomadaCliente.getInputStream());  
			
			// Associa uma string a entrada padrao (teclado)
			BufferedReader teclado = new BufferedReader(new 
			InputStreamReader(System.in));
			
			while (true) {
				//Declaração de alguns tipos de dados que vão ser utilizados
				String mensagem;
				ManipulacaoArquivos novo = new ManipulacaoArquivos();
				ManipulacaoArquivos baixado = new ManipulacaoArquivos();
				System.out.println("Digite o nome do Arquivo(com extensão, Ex: .jar, .zip)(Bye para sair):");
				
				//lê o teclado
				mensagem = teclado.readLine();
				//Colocar o que foi digitado no teclado, dentro do nome de um objeto que representa nosso arquivo
				novo.setNome(mensagem);
				//Envia o array pelo fluxo de saida socket
				bufferSaida.writeObject(novo);
				//Força a gravação de todos os bytes do buffer
				//bufferSaida.flush();
				
				// Termina se usuario digitou bye
				if(mensagem.equals("Bye")) {
					break;
				}
				
				//Verificação de existencia do arquivo solicitado

				int existe = Integer.parseInt(bufferEntrada.readUTF());
				//Se o servidor enviar um dado com o valor 1, o arquivo existe, se não, ele printa que não foi encontrado
				if(existe == 1) {
				//Receber Arquivo e ler ele no InputStream
				byte[] lerArquivo = new byte[tomadaCliente.getReceiveBufferSize()];
				BufferedInputStream arqv = new BufferedInputStream(
				           tomadaCliente.getInputStream());
				arqv.read(lerArquivo);
				
				//Objeto criado recebe os bytes do arquivo que o rervidor enviou
				baixado = (ManipulacaoArquivos) bytesParaObjeto(lerArquivo);
				//System.out.println(baixado.getNome());
				//Caminho onde será salvo o arquivo
				String caminhoArquivo = "C:/Users/lucas/eclipse-workspace/TcpAula/client/" + mensagem;
				//Construindo Arquivo
				FileOutputStream fim = new FileOutputStream(caminhoArquivo);
				//System.out.println(baixado.getConteudo());
				fim.write(baixado.getConteudo());
				System.out.println("O arquivo '" + baixado.getNome() + "' foi encontrado e armazenado com sucesso!");
				fim.close();
				}else {
					System.out.println("Arquivo nao encontrado");
				}
							
			}
			//fecha os buffers e o socket
			bufferSaida.close();
			bufferEntrada.close();
			teclado.close();
			tomadaCliente.close();
		} catch (Exception ex) {
			System.out.println("Erro ao iniciar o servidor" + ex.getMessage());
		}
	}
	//Transformar os bytes recebidos em um Objeto do time ManipulacaoArquivos
	 private static Object bytesParaObjeto(byte[] lerArquivo) {
	     Object obj = null;
	     ByteArrayInputStream bis = null;
	     ObjectInputStream ois = null;
	     try {
	        bis = new ByteArrayInputStream(lerArquivo);
	        ois = new ObjectInputStream(bis);
	        obj = ois.readObject();

	        bis.close();
	        ois.close();

	     } catch (IOException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	     } catch (ClassNotFoundException e) {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	     }

	     return obj;

	   }



}
