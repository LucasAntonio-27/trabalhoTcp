/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Link referencia: https://www.devmedia.com.br/java-socket-transferencia-de-arquivos-pela-rede/32107
 * Aluno: Lucas Antonio da Silva Lima
 */
package tcpServidor;
import java.net.*;
import java.io.*;
import tcpArquivos.ManipulacaoArquivos;

public class ServidorTCP {

	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
		// cria socket na porta 4444
		try {
			ServerSocket tomadaServidora = new ServerSocket(4444);
			// aguarda solicitação de cliente e aceita conexão
			System.out.println("Servidor Aguardando Conexoes");
			Socket tomadaCliente = tomadaServidora.accept();

			//Cria buffers de array de bytes, uma para enviar e para receber a conexão com o cliente
			ObjectInputStream bufferEntrada = new ObjectInputStream(tomadaCliente.getInputStream());
			BufferedOutputStream bf = new BufferedOutputStream(tomadaCliente.getOutputStream());
			DataOutputStream bufferSaida = new DataOutputStream(tomadaCliente.getOutputStream());
			
			while (true) {
				//cria objeto da Classe ManipulaArquivos para receber os dados do arquivo a ser enviado
				ManipulacaoArquivos novo = new ManipulacaoArquivos();
				
				// recebe array do socket cliente
				novo = (ManipulacaoArquivos) bufferEntrada.readObject();
				// Pego o nome do arquivo que o cliente busca
				String nomeArquivo = novo.getNome();
				System.out.println(nomeArquivo);
				
				//Diretório onde será feita a busca 
				String diretorioBase = "C:/Users/lucas/eclipse-workspace/TcpAula/server/";
				String caminhoArquivo = diretorioBase + nomeArquivo;
				System.out.println("Cliente Solicitou arquivo: "+ caminhoArquivo);
				//termina ser recebeu bye
				if (nomeArquivo.equals("Bye")) {
					break;
				}
				
				//Pega o arquivo do caminho indicado e coloca ele em um tipo File
				File arquivoSelecionado = new File(caminhoArquivo);
				//Verificação para saber se o Arquivo existe, se não existir, ele enviar uma mensagem com valor 0
				//para o cliente, e encerra o trabalho de envio de arquivo
				if(arquivoSelecionado.exists()==false) {
					String msg = "0";
					bufferSaida.writeUTF(msg);
				}else {
					
					String msg = "1";
					bufferSaida.writeUTF(msg);
					//Vetor de bytes que vai receber o tamanho que precisa ter, para receber os bytes do arquivo
					byte[] arquivoEnviar = new byte[(int) arquivoSelecionado.length()];
					FileInputStream fl= new FileInputStream(arquivoSelecionado);
					novo.setNome(nomeArquivo);
					novo.setConteudo(arquivoEnviar);
					fl.read(arquivoEnviar);
					fl.close();

					System.out.println(arquivoEnviar.length);

					byte[] bytea = serializarArquivo(novo);

					bf.write(bytea);
					bf.flush();
				}
			}
			bf.close();
			bufferSaida.close();
			bufferEntrada.close();
			tomadaCliente.close();
			tomadaServidora.close();
		} catch(IOException ex){
			System.out.println("Erro ao iniciar o servidor " + ex.getMessage());
		}
		

	}
	private static byte[] serializarArquivo(ManipulacaoArquivos novo){
		byte[] bytes = null;
		try {
			
		      ByteArrayOutputStream bao = new ByteArrayOutputStream();
		      ObjectOutputStream ous;
		      ous = new ObjectOutputStream(bao);
		      ous.writeObject(novo);
		      ous.flush();
		      ous.close();
		      bao.close();
		      bytes = bao.toByteArray();
		   } catch (IOException e) {
		      e.printStackTrace();
		   }
		   return bytes;
		}

}
