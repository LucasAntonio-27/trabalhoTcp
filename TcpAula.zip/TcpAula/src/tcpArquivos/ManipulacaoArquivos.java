/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Link referencia: https://www.devmedia.com.br/java-socket-transferencia-de-arquivos-pela-rede/32107
 * Aluno: Lucas Antonio da Silva Lima
 */
package tcpArquivos;
import java.io.*;

//Classe que cria o objeto que recebe os dados do Arquivo
public class ManipulacaoArquivos implements Serializable{
	
	private String nome;
	private byte[] conteudo;
	//private String diretorio;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public byte[] getConteudo(){
		return conteudo;
	}
	public void setConteudo(byte[] conteudo) {
		this.conteudo = conteudo;
	}
	
}
