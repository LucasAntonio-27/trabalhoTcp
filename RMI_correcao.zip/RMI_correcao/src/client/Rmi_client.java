/* UNIVERSSIDADE FEDERAL DO SUL E SUDESTE
 * Alunos: Lucas Antonio da Silva Lima, Lucas Leite de Oliveira.
 * */
package client;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import server.CorrigirRmi;
public class Rmi_client {

	public static void main(String[] args) throws Exception{

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		while(true) {
			try {
				//Declaração de variaveis que serão utilizadas
				int q,n;
				String[] array = new String[2];
				//Criar registro para instanciar o local host
				Registry registry = LocateRegistry.getRegistry("localhost", 5000);
				//Criar e instanciar o corretor
				CorrigirRmi corrigir = (CorrigirRmi) registry.lookup("Corretor");
				//Receber Dados do teclado
				System.out.println("Digite os dados da questao:");
				String teclado = in.readLine();
				
				//Separar os dados em 3 partes para utilizar no corretor
				array = teclado.split(";");
				q = Integer.parseInt(array[0]);
				n = Integer.parseInt(array[1]);
				//chama o método que verifica as respostas e enviar em bytes para
				byte[] result = corrigir.corrigido(q,n,array[2]);
				System.out.println("o Resultado e: " + new String(result, "UTF-8"));
			}catch(Exception ex) {
				ex.printStackTrace();
			}
		}
	}

}
