/* UNIVERSSIDADE FEDERAL DO SUL E SUDESTE
 * Alunos: Lucas Antonio da Silva Lima, Lucas Leite de Oliveira.
 * */
package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Rmi_correctq extends UnicastRemoteObject implements CorrigirRmi{
	protected Rmi_correctq() throws RemoteException{
		super();
	}
	private static final long serialVersionUID = 1L;
	//Classe que faz a correção do questionario
	public byte[] corrigido(int q, int r,String vf) {
		//Criação de variaveis e vetores
		byte[] resposta = new byte[100];
		char[] array = vf.toCharArray();
		String retorno;
		int i=0,e=0,c=0;
		//Switch case que vai ver em qual questão o cliente entrou
		switch(q) {
		case 1:
			//vetor de char que contem as respostas certas
			char[] corretor1 = new char[]{'v','v','f','f'};
			//for que vai rodando e comparando o vetor das respostas recebidas com o vetor das corretas
			for(i=0; i<4; i++) {
				if(array[i] == corretor1[i])
					c++;
				else
					e++;
			}
			retorno = q + ";" + c + ";" + e;
			resposta = retorno.getBytes();
			break;
		case 2:
			char[] corretor2 = new char[]{'f','f','f','v'};
			for(i=0; i<4; i++) {
				if(array[i] == corretor2[i])
					c++;
				else
					e++;
			}
			retorno = q + ";" + c + ";" + e;
			resposta = retorno.getBytes();
			break;
		case 3:
			char[] corretor3 = new char[]{'v','f','v','f'};
			for(i=0; i<4; i++) {
				if(array[i] == corretor3[i])
					c++;
				else
					e++;
			}
			retorno = q + ";" + c + ";" + e;
			resposta = retorno.getBytes();
			break;
		default:
			resposta = "Questão inexistente".getBytes();
			break;
		}

		return resposta;
	}
}