/* UNIVERSSIDADE FEDERAL DO SUL E SUDESTE
 * Alunos: Lucas Antonio da Silva Lima, Lucas Leite de Oliveira.
 * */
package server;

import java.rmi.Remote;
//interface que disponibiliza esse metodo para que seja remoto
public interface CorrigirRmi extends Remote {
	byte[] corrigido(int q, int r, String vf) throws Exception;
}
