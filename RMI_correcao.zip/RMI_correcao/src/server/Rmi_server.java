/* UNIVERSSIDADE FEDERAL DO SUL E SUDESTE
 * Alunos: Lucas Antonio da Silva Lima, Lucas Leite de Oliveira.
 * */
package server;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Rmi_server {

	protected Rmi_server() throws RemoteException{
		super();
	}
	public static void main(String[] args) throws RemoteException, AlreadyBoundException{
		// TODO Auto-generated method stub
		java.rmi.registry.LocateRegistry.createRegistry(5000);
		//criando um novo objeto do tipo Rmi_correctq
		Rmi_correctq corretor = new Rmi_correctq();
		//Criar registro para instanciar o local host
		Registry registry = LocateRegistry.getRegistry("localhost",5000);
		//Registra e instancia o nome da classe do serviço de nomes
		registry.bind("Corretor", corretor);
		System.out.println("Servidor pronto");
		
	}

}
