/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Aluno: Lucas Antonio da Silva Lima
 */
package udpQuestionario;

//import java.util.Scanner;

public class QuestionarioUDP {
	String resposta = null;
	//int cont;
	
	//Scanner teclado = new Scanner(System.in);
	public String Perguntas(int cont){
			String quest=null;
			switch(cont) {
				case 1:
					quest = "Questao (1): A terra tem a maior parte da sua superficie coberta por agua: ";
					//System.out.println("Questão (1): A terra tem a maior parte da sua superficie coberta por água: ");
					break;
				case 2:
					quest = "Questao (2): A lua e o satelite natural da terra: ";
					//System.out.println("Questão (2): A terra tem a maior parte da sua superficie coberta por água: ");
					break;
				case 3:
					quest = "Questao (3): A terra e duas vezes maior que saturno: ";
					//System.out.println("Questão (3): A terra tem a maior parte da sua superficie coberta por água: ");
					break;
				case 4:
					quest = "Questao (4): A terra e plana: ";
					//System.out.println("Questão (4): A terra tem a maior parte da sua superficie coberta por água: ");
					break;
			}
			//resposta = teclado.nextLine();
			
		return quest;
	}
	public int Verificacao(String resposta, int questao) {
		int vf = 0;
		String V = "V";
		String F = "F";
			switch(questao) {
			case 1:
				if(resposta.trim().equals(V))
					vf = 1;
				else
					vf = 2;
				break;
			case 2:
				if(resposta.trim().equals(V))
					vf = 1;
				else
					vf = 2;
				break;
			case 3:
				if(resposta.trim().equals(F))
					vf = 1;
				else
					vf = 2;
				break;
			case 4:
				if(resposta.trim().equals(F))
					vf = 1;
				else
					vf = 2;
				break;
			
			}
		return vf;
	}
}
