/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Aluno: Lucas Antonio da Silva Lima
 */
package udpServidor;
import java.net.*;
import java.util.Arrays;

import udpQuestionario.QuestionarioUDP;
import java.io.*;
//import udpCliente.ThreadCliente;

public class ServidorUDP {
	public static void main(String args[]) {
		DatagramSocket s = null;
		try {
			int i=1,certas=0,erradas=0;
			s = new DatagramSocket(6789); // cria um socket UDP
			byte[] buffer = new byte[1000];
			while (true) {
				System.out.println("*** Servidor aguardando request");
				// cria datagrama para recepcionar solicitação do cliente
				DatagramPacket req = new DatagramPacket(buffer, buffer.length);
				s.receive(req);
				System.out.println("*** Request recebido de: " + req.getSocketAddress());
				// envia resposta
				String quest = "Questionario de Ciencias Iniciado!\n ******** Responda com V ou F(verdadeiro ou falso) para as perguntas a seguir ********";
				buffer = quest.getBytes();
				DatagramPacket resp = new DatagramPacket(buffer, buffer.length,
						req.getAddress(), req.getPort());
				s.send(resp);
				while(i < 5) {
					Arrays.fill(buffer, (byte)0);
					QuestionarioUDP pergunta = new QuestionarioUDP();
					 String q = pergunta.Perguntas(i);
					 buffer = q.getBytes();
					 System.out.println(q);
					DatagramPacket question = new DatagramPacket(buffer, buffer.length,
							req.getAddress(), req.getPort());
					s.send(question);
					Arrays.fill(buffer, (byte)0);
					
					DatagramPacket answer = new DatagramPacket(buffer, buffer.length);
					s.receive(answer);
					String respostaDoCliente = new String(answer.getData()).toUpperCase();
					System.out.println("A Resposta do Cliente foi: "+ respostaDoCliente);
					int correcao = pergunta.Verificacao(respostaDoCliente, i);
					System.out.println(correcao);
					if(correcao == 1)
						certas++;
					else if(correcao == 2)
						erradas++;
					i++;
				}
				Arrays.fill(buffer, (byte)0);
				String result = "Certas: "+ certas+ "\n" + "Erradas: "+ erradas;
				buffer = result.getBytes();
				DatagramPacket resultado = new DatagramPacket(buffer, buffer.length,
						req.getAddress(), req.getPort());
				s.send(resultado);
			}

		} catch (SocketException e) {
			System.out.println("Erro de socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Erro envio/recepcao pacote: " + e.getMessage());         
		} finally {
			if (s != null) s.close();
		}     
	}
}

