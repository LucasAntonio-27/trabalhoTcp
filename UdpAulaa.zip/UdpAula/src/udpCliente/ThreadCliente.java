/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Aluno: Lucas Antonio da Silva Lima
 */
package udpCliente;

import java.net.*;
import java.io.*;
import java.util.*;

public class ThreadCliente implements Runnable {
	protected String servidor="localhost";
	protected String msg=" OK ";
	protected int porta=6789;
	int i=1;
	ThreadCliente(String args[]) {
		if (args.length > 0) servidor = args[0];
		if (args.length > 1) porta = Integer.parseInt(args[1]);
		if (args.length > 2) msg = args[2];
	}
	public void run() { // a interface Runnable exige a implementação do método run
		Thread thread = Thread.currentThread();
		DatagramSocket s = null;
		Scanner teclado = new Scanner(System.in);
		
		try {
			s = new DatagramSocket(); // cria um socket UDP
			System.out.println("* " + thread.getName() + " * Socket criado na porta: " + s.getLocalPort());
			byte[] m = msg.getBytes(); // transforma arg em bytes
			InetAddress serv = InetAddress.getByName(servidor);

			DatagramPacket req = new DatagramPacket(m, msg.length(), serv, porta);
			s.send(req); // envia datagrama contendo a mensagem m
			System.out.println("* " + thread.getName() + " * Conexao iniciada: " + msg);
			byte[] buffer = new byte[1000];
			DatagramPacket resp = new DatagramPacket(buffer, buffer.length);
			s.setSoTimeout(10000); // timeout em ms
			s.receive(resp); // aguarda resposta do servidor - bloqueante
			System.out.println("* " + thread.getName() + " * Resposta do servidor:" + new String(resp.getData()));
				while(i < 5) {
					Arrays.fill(buffer, (byte)0);
					DatagramPacket packPerg = new DatagramPacket(buffer, buffer.length);
					s.setSoTimeout(10000); // timeout em ms
					s.receive(packPerg);
					System.out.println(new String(packPerg.getData()));
					String r = teclado.nextLine();
					
					//System.out.println(r);
					byte[] resposta = r.getBytes(); // transforma arg em bytes
					//InetAddress serv = InetAddress.getByName(servidor);

					DatagramPacket packResp = new DatagramPacket(resposta, r.length(), serv, porta);
					s.send(packResp); // envia datagrama contendo a mensagem m
					
					i++;
				}
				Arrays.fill(buffer, (byte)0);
				DatagramPacket correcao = new DatagramPacket(buffer, buffer.length);
				s.setSoTimeout(10000); // timeout em ms
				s.receive(correcao);
				System.out.println(new String(correcao.getData()));
				teclado.close();
		} catch (SocketException e) {
			// timeout, erro na criação
			System.out.println("* " + thread.getName() + " * Erro socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("* " + thread.getName() + " * Erro envio/recepcao do pacote: " + e.getMessage());
		}  finally {
			if (s != null) s.close();
		}
		
	}
}
