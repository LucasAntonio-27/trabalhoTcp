/*
 * UNIFESSPA - Universidade Federal do Sul e Sudeste do Pará
 * Aluno: Lucas Antonio da Silva Lima
 */
package udpCliente;
public class ClienteUDP {
	public static void main(String args[]) {
        Thread cliente1 = new Thread(new ThreadCliente(args), "CLIENTE 1");
        cliente1.start();
    }
}
