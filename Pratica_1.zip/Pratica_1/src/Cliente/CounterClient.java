/*UNIFESSPA - UNIVERSIDADE FEDERAL DO SUL E SUDESTE
Alunos: Lucas Antonio da Silva Lima, Lucas Leite De Oliveira.
*/
package Cliente;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import Servidor.Counter;
import Servidor.CounterServer;

public class CounterClient {
	public static void main(String[] args) throws RemoteException{
		try {
			Registry registry = LocateRegistry.getRegistry("localhost", 5000);

			CounterServer stub= (CounterServer)registry.lookup("Contador");

			int c = 0;
			Counter cont = stub.createCounter(c);
			System.out.println("Contador" + cont);
		} catch (Exception ex)	{
			ex.printStackTrace();
		}
	}
}