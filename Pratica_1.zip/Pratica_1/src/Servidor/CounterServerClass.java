/*UNIFESSPA - UNIVERSIDADE FEDERAL DO SUL E SUDESTE
Alunos: Lucas Antonio da Silva Lima, Lucas Leite De Oliveira.
*/
package Servidor;
import java.nio.channels.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CounterServerClass{
	protected CounterServerClass() throws RemoteException{
		super();
	}
	public static void main(String args[]) throws RemoteException, AlreadyBoundException, java.rmi.AlreadyBoundException{
		java.rmi.registry.LocateRegistry.createRegistry(5000);
		//Cria uma instancia do contador
		Create server = new Create();
		Registry registry = LocateRegistry.getRegistry("localhost", 5000);
		registry.bind("Contador", server);
		System.out.println("Servidor funcionando");
	}
}