/*UNIFESSPA - UNIVERSIDADE FEDERAL DO SUL E SUDESTE
Alunos: Lucas Antonio da Silva Lima, Lucas Leite De Oliveira.
*/
package Servidor;
import java.rmi.*;

public interface Counter extends Remote {
	//Retorna o valor atual do contador
	public int getValue() throws RemoteException;
	
	//Incrementa o contador e retorna seu novo valor
	public int nextValue() throws RemoteException;
	
}
