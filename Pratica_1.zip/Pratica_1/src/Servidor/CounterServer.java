/*UNIFESSPA - UNIVERSIDADE FEDERAL DO SUL E SUDESTE
Alunos: Lucas Antonio da Silva Lima, Lucas Leite De Oliveira.
*/
package Servidor;
import java.rmi.*;

public interface CounterServer  extends Remote{
	
	//Cria um contador com o valor inicial especificado com parametro.
	// Retorna uma referencia com a qual o contador pode ser acessado remotamente.
	public Counter createCounter(int initValue) throws RemoteException;

}
