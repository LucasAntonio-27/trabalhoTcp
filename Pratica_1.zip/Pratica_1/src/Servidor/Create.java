/*UNIFESSPA - UNIVERSIDADE FEDERAL DO SUL E SUDESTE
Alunos: Lucas Antonio da Silva Lima, Lucas Leite De Oliveira.
*/
package Servidor;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Create extends UnicastRemoteObject implements CounterServer{
	public Create() throws RemoteException{
		super ();
		}
	private static final long serialVersionUID = 1L;
	
	public Counter createCounter(int i) throws RemoteException {
		java.rmi.registry.LocateRegistry.createRegistry(5000);
	Counter counter = new CounterClass(i);
UnicastRemoteObject.exportObject(counter, 0);
return counter;
	}
}
