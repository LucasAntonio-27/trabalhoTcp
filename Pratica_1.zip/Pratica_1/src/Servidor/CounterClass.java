/*UNIFESSPA - UNIVERSIDADE FEDERAL DO SUL E SUDESTE
Alunos: Lucas Antonio da Silva Lima, Lucas Leite De Oliveira.
*/
package Servidor;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CounterClass extends UnicastRemoteObject implements Counter{
	protected CounterClass(int i) throws RemoteException {
		super();
	}
	private static final long serialVersionUID = 1L;
	private int counter;
	
	public int getValue(){
		return counter;
	}
	public int nextValue() throws RemoteException{
		return counter++;
	}
}
